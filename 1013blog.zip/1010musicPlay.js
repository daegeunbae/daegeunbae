
const audioPlayer = document.getElementById("audioPlayer");
const playBtn = document.getElementById("playBtn");
const backBtn = document.getElementById("backBtn");
const forwardBtn = document.getElementById("forwardBtn");

// 음악 파일 경로 및 정보
const musicFiles = ["music/leonell.mp3","music/ifyougo.mp3","music/shivers.mp3","music/bonfire.mp3","music/everybreath.mp3","music/johnpark.mp3","music/permissionto.mp3"];
let currentTrackIndex = 0;

// 음악 재생 함수
function playMusic() {
    audioPlayer.src = musicFiles[currentTrackIndex];
    audioPlayer.load();
    audioPlayer.play();
    playBtn.classList.remove("bx-play-circle");
    playBtn.classList.add("bx-pause");
    updateSongName(); // 곡 제목 업데이트
}

// 곡 제목 업데이트 함수
function updateSongName() {
    const songName = document.querySelector(".songName");
    songName.textContent = musicFiles[currentTrackIndex].split("/").pop(); // 파일 이름 표시
}

playBtn.addEventListener("click", () => {
    if (audioPlayer.paused) {
        audioPlayer.play();
        playBtn.classList.remove("bx-play-circle");
        playBtn.classList.add("bx-pause");
    } else {
        audioPlayer.pause();
        playBtn.classList.remove("bx-pause");
        playBtn.classList.add("bx-play-circle");
    }
});

backBtn.addEventListener("click", () => {
    if (currentTrackIndex > 0) {
        currentTrackIndex--;
        playMusic(); // 이전 곡 재생
    }
});

forwardBtn.addEventListener("click", () => {
    if (currentTrackIndex < musicFiles.length - 1) {
        currentTrackIndex++;
        playMusic(); // 다음 곡 재생
    }
});

// 페이지 로드 시 첫 번째 곡을 재생
window.onload = function () {
    playMusic();
};
