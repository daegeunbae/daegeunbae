var typed = new Typed(".text", {
    strings: ["Project Manager.", "Data Scientist.", "Marketer."],
    typeSpeed: 100,
    backSpeed: 100,
    backDelay: 1000,
    loop: true
});

